package com.harshit.madad.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Pink100 = Color(0xFFE46489)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val lightBlue = Color(color = 0xFF3693E9)
val lightOrange = Color(color = 0xFFfff7ef)
val lightGreen = Color(color = 0xFF50ccc3)